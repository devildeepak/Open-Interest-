import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="NIFTY OI Change Dashboard", layout="wide")
st.title("📈 NIFTY Minute-wise ITM OI Change (CALL vs PUT)")

data_dir = "option_data"
strike_step = 50  # NIFTY usually has 50 point strike difference

# User input: number of ITM strikes
n = st.slider("Number of ITM strikes towards CALL & PUT (n):", min_value=1, max_value=30, value=14)

@st.cache_data(ttl=30)
def load_all_data():
    files = sorted([f for f in os.listdir(data_dir) if f.endswith('.csv')])
    dfs = []
    for f in files:
        df = pd.read_csv(os.path.join(data_dir, f))
        df["file_time"] = f.split('_')[-1].split('.')[0]
        dfs.append(df)
    return dfs

def find_atm_strike(spot):
    return round(spot / strike_step) * strike_step

def calculate_oi_changes(all_dfs, n):
    results = []
    for i in range(1, len(all_dfs)):
        df_prev = all_dfs[i-1]
        df_now = all_dfs[i]

        spot = df_now["strike"].mean()  # as proxy
        atm_strike = find_atm_strike(spot)

        call_strikes = [atm_strike + strike_step * j for j in range(1, n+1)]
        put_strikes = [atm_strike - strike_step * j for j in range(1, n+1)]

        df_now_ce = df_now[(df_now["type"]=="CE") & (df_now["strike"].isin(call_strikes))]
        df_prev_ce = df_prev[(df_prev["type"]=="CE") & (df_prev["strike"].isin(call_strikes))]
        df_now_pe = df_now[(df_now["type"]=="PE") & (df_now["strike"].isin(put_strikes))]
        df_prev_pe = df_prev[(df_prev["type"]=="PE") & (df_prev["strike"].isin(put_strikes))]

        df_ce = pd.merge(df_now_ce, df_prev_ce, on="strike", suffixes=("_now", "_prev"))
        df_pe = pd.merge(df_now_pe, df_prev_pe, on="strike", suffixes=("_now", "_prev"))

        df_ce["oi_change"] = df_ce["OI_now"] - df_ce["OI_prev"]
        df_pe["oi_change"] = df_pe["OI_now"] - df_pe["OI_prev"]

        ce_change = df_ce["oi_change"].sum()
        pe_change = df_pe["oi_change"].sum()

        time_label = df_now["file_time"].iloc[0]
        results.append({"time": time_label, "CALL_OI_Change": ce_change, "PUT_OI_Change": pe_change})

    return pd.DataFrame(results)

all_dfs = load_all_data()
if len(all_dfs) < 2:
    st.info("Waiting for enough data... keep background fetcher running.")
else:
    df_result = calculate_oi_changes(all_dfs, n)
    st.line_chart(df_result.set_index("time")[["CALL_OI_Change", "PUT_OI_Change"]])
    st.dataframe(df_result.tail(10))

st.caption("✅ Adjust 'n' above. Data updates every minute if background fetcher is running.")