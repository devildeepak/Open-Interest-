import requests
import pandas as pd
from datetime import datetime
import time
import os

symbol = "NIFTY"
strike_step = 50
data_dir = "option_data"

if not os.path.exists(data_dir):
    os.makedirs(data_dir)

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/option-chain"
})
session.get("https://www.nseindia.com")  # set cookies

def fetch_option_chain():
    url = f"https://www.nseindia.com/api/option-chain-indices?symbol={symbol}"
    response = session.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Failed to fetch: {response.status_code}")
        return None

def process_data(data):
    records = []
    timestamp = datetime.now()
    for item in data["records"]["data"]:
        strike = item.get("strikePrice")
        ce = item.get("CE")
        pe = item.get("PE")
        if ce:
            records.append({
                "time": timestamp,
                "strike": strike,
                "type": "CE",
                "OI": ce.get("openInterest"),
                "changeInOI": ce.get("changeinOpenInterest"),
                "lastPrice": ce.get("lastPrice")
            })
        if pe:
            records.append({
                "time": timestamp,
                "strike": strike,
                "type": "PE",
                "OI": pe.get("openInterest"),
                "changeInOI": pe.get("changeinOpenInterest"),
                "lastPrice": pe.get("lastPrice")
            })
    return pd.DataFrame(records)

while True:
    print("Fetching NIFTY option chain...")
    data = fetch_option_chain()
    if data:
        df = process_data(data)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        filename = os.path.join(data_dir, f"option_chain_{timestamp}.csv")
        df.to_csv(filename, index=False)
        print(f"Saved {filename}")
    time.sleep(60)